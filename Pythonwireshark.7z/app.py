import os
import subprocess
import threading
import time
import pyshark
from flask import Flask, render_template, jsonify, request, send_from_directory

# --- Configuración y Estado Global ---
app = Flask(__name__)
OUTPUT_DIR = "capturas_por_dispositivo"

# Variables de estado para controlar el hilo de captura
capture_thread = None
is_capturing = False
# Usamos un lock para acceder a la lista de IPs desde múltiples hilos de forma segura
detected_ips_lock = threading.Lock()
detected_ips = {} # { "ip_address": "file_path.pcap" }

# --- Lógica de Captura ---

def run_capture(interface_name):
    """Esta función se ejecuta en un hilo separado para capturar paquetes."""
    global is_capturing, detected_ips

    # Asegura que el directorio de salida exista
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    
    live_caps = {}
    
    try:
        capture = pyshark.LiveCapture(interface=interface_name)
        # Bucle que se controla con la variable global is_capturing
        for packet in capture.sniff_continuously():
            if not is_capturing:
                break # Salir del bucle si se detiene la captura

            if 'IP' in packet:
                ip_src = packet.ip.src
                ip_dst = packet.ip.dst
                
                # Procesamos ambas IPs (origen y destino)
                for ip_addr in {ip_src, ip_dst}:
                    with detected_ips_lock:
                        if ip_addr not in detected_ips:
                            filepath = os.path.join(OUTPUT_DIR, f"{ip_addr}.pcap")
                            detected_ips[ip_addr] = filepath
                            live_caps[ip_addr] = pyshark.LiveRingCapture(output_file=filepath)
                            print(f"Nuevo dispositivo: {ip_addr}")
                    
                    # Guardamos el paquete en el archivo correspondiente
                    if ip_addr in live_caps:
                        live_caps[ip_addr].sniff(packet_count=1, packet=packet)

    except Exception as e:
        print(f"Error en el hilo de captura: {e}")
    finally:
        # Limpieza al finalizar
        for cap in live_caps.values():
            cap.close()
        is_capturing = False
        print("Hilo de captura finalizado.")


# --- Rutas del Servidor Web (Endpoints) ---

@app.route('/')
def index():
    """Sirve la página principal del frontend."""
    return render_template('index.html')

@app.route('/api/interfaces')
def get_interfaces():
    """Obtiene y devuelve la lista de interfaces de red."""
    try:
        # Ejecuta 'tshark -D' para listar interfaces y captura la salida
        result = subprocess.run(['tshark', '-D'], capture_output=True, text=True, check=True)
        interfaces = [line.split('(')[-1].replace(')','').strip() for line in result.stdout.strip().split('\n') if '(' in line]
        return jsonify(interfaces)
    except Exception as e:
        print(f"Error al listar interfaces: {e}")
        return jsonify({"error": "No se pudo obtener la lista de interfaces. ¿Está Wireshark instalado y en el PATH?"}), 500

@app.route('/api/start', methods=['POST'])
def start_capture():
    """Inicia la captura en un hilo."""
    global capture_thread, is_capturing, detected_ips
    
    if is_capturing:
        return jsonify({"status": "error", "message": "La captura ya está en progreso."}), 400

    interface = request.json.get('interface')
    if not interface:
        return jsonify({"status": "error", "message": "No se especificó una interfaz."}), 400
    
    is_capturing = True
    # Reiniciamos la lista de IPs detectadas para la nueva sesión
    with detected_ips_lock:
        detected_ips = {}
        
    capture_thread = threading.Thread(target=run_capture, args=(interface,))
    capture_thread.start()
    
    return jsonify({"status": "ok", "message": f"Captura iniciada en '{interface}'."})

@app.route('/api/stop', methods=['POST'])
def stop_capture():
    """Detiene el hilo de captura."""
    global is_capturing
    
    if not is_capturing:
        return jsonify({"status": "error", "message": "No hay ninguna captura activa."}), 400

    is_capturing = False
    if capture_thread:
        capture_thread.join(timeout=5) # Espera a que el hilo termine

    return jsonify({"status": "ok", "message": "La captura ha sido detenida."})

@app.route('/api/status')
def get_status():
    """Devuelve el estado actual de la captura y los dispositivos detectados."""
    with detected_ips_lock:
        return jsonify({
            "is_capturing": is_capturing,
            "detected_ips": detected_ips
        })
        
@app.route('/download/<filename>')
def download_file(filename):
    """Permite descargar los archivos pcap generados."""
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)


if __name__ == '__main__':
    print("Iniciando servidor web...")
    print(f"Abre tu navegador y ve a http://127.0.0.1:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)