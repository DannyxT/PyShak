import os
import subprocess
import threading
import pyshark
from flask import Flask, render_template, jsonify, request, send_from_directory

# --- Configuración y Estado Global ---
app = Flask(__name__)
OUTPUT_DIR = "capturas_por_dispositivo"

capture_thread = None
is_capturing = False
detected_ips_lock = threading.Lock()
detected_ips = {}
capturing_target_ip = None # NUEVA variable de estado

# --- Lógica de Captura Modificada ---

def run_capture(interface_name, target_ip=None):
    """
    Función de captura que ahora acepta una IP específica para filtrar.
    """
    global is_capturing, detected_ips, capturing_target_ip

    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    
    # Creamos el filtro de captura si se proporciona una IP
    bpf_filter = f"host {target_ip}" if target_ip else None
    
    try:
        capture = pyshark.LiveCapture(interface=interface_name, bpf_filter=bpf_filter)
        print(f"Iniciando captura en '{interface_name}' con filtro: '{bpf_filter or 'Ninguno'}'")
        
        # Lógica para una IP específica
        if target_ip:
            filepath = os.path.join(OUTPUT_DIR, f"captura_{target_ip}.pcap")
            # Usamos un solo objeto de guardado
            single_cap = pyshark.LiveRingCapture(output_file=filepath)
            
            with detected_ips_lock:
                detected_ips[target_ip] = filepath

            for packet in capture.sniff_continuously():
                if not is_capturing: break
                single_cap.sniff(packet_count=1, packet=packet)
            single_cap.close()

        # Lógica original para todos los dispositivos
        else:
            live_caps = {}
            for packet in capture.sniff_continuously():
                if not is_capturing: break
                if 'IP' in packet:
                    for ip_addr in {packet.ip.src, packet.ip.dst}:
                        with detected_ips_lock:
                            if ip_addr not in detected_ips:
                                filepath = os.path.join(OUTPUT_DIR, f"{ip_addr}.pcap")
                                detected_ips[ip_addr] = filepath
                                live_caps[ip_addr] = pyshark.LiveRingCapture(output_file=filepath)
                                print(f"Nuevo dispositivo: {ip_addr}")
                        
                        if ip_addr in live_caps:
                            live_caps[ip_addr].sniff(packet_count=1, packet=packet)
            for cap in live_caps.values():
                cap.close()

    except Exception as e:
        print(f"Error en el hilo de captura: {e}")
    finally:
        is_capturing = False
        capturing_target_ip = None # Limpiar el estado
        print("Hilo de captura finalizado.")


# --- Rutas del Servidor Web (Endpoints) ---

# ... (@app.route('/') y @app.route('/api/interfaces') se mantienen igual) ...

@app.route('/api/start', methods=['POST'])
def start_capture():
    """Inicia la captura, ahora aceptando una IP opcional."""
    global capture_thread, is_capturing, detected_ips, capturing_target_ip
    
    if is_capturing:
        return jsonify({"status": "error", "message": "La captura ya está en progreso."}), 400

    data = request.json
    interface = data.get('interface')
    target_ip = data.get('target_ip') # Obtenemos la IP del frontend

    if not interface:
        return jsonify({"status": "error", "message": "No se especificó una interfaz."}), 400
    
    is_capturing = True
    capturing_target_ip = target_ip # Guardamos la IP objetivo en el estado global
    with detected_ips_lock:
        detected_ips = {}
        
    # Pasamos la IP objetivo al hilo
    capture_thread = threading.Thread(target=run_capture, args=(interface, target_ip))
    capture_thread.start()
    
    message = f"Captura iniciada en '{interface}'."
    if target_ip:
        message += f" Filtrando por IP: {target_ip}"
        
    return jsonify({"status": "ok", "message": message})

# ... (@app.route('/api/stop') se mantiene igual, aunque podríamos limpiar capturing_target_ip aquí también) ...

@app.route('/api/status')
def get_status():
    """Devuelve el estado, incluyendo la IP que se está capturando."""
    with detected_ips_lock:
        return jsonify({
            "is_capturing": is_capturing,
            "detected_ips": detected_ips,
            "capturing_target_ip": capturing_target_ip # Enviamos la IP objetivo al frontend
        })

# ... (El resto del archivo se mantiene igual) ...

# El código completo para app.py sería:
# ... (Copiar y pegar todo el código de app.py y aplicar los cambios descritos arriba) ...
# Por brevedad, solo he mostrado las secciones modificadas. Es importante integrar estos cambios en el archivo completo.

# --- Código completo y funcional de app.py ---

import os
import subprocess
import threading
import pyshark
from flask import Flask, render_template, jsonify, request, send_from_directory

app = Flask(__name__)
OUTPUT_DIR = "capturas_por_dispositivo"

capture_thread = None
is_capturing = False
detected_ips_lock = threading.Lock()
detected_ips = {}
capturing_target_ip = None

def run_capture(interface_name, target_ip=None):
    global is_capturing, detected_ips, capturing_target_ip
    if not os.path.exists(OUTPUT_DIR): os.makedirs(OUTPUT_DIR)
    
    bpf_filter = f"host {target_ip}" if target_ip else None
    
    try:
        capture = pyshark.LiveCapture(interface=interface_name, bpf_filter=bpf_filter)
        print(f"Iniciando captura en '{interface_name}' con filtro: '{bpf_filter or 'Ninguno'}'")
        
        if target_ip:
            filepath = os.path.join(OUTPUT_DIR, f"captura_{target_ip}.pcap")
            single_cap = pyshark.LiveRingCapture(output_file=filepath)
            with detected_ips_lock: detected_ips[target_ip] = filepath
            for packet in capture.sniff_continuously():
                if not is_capturing: break
                single_cap.sniff(packet_count=1, packet=packet)
            single_cap.close()
        else:
            live_caps = {}
            for packet in capture.sniff_continuously():
                if not is_capturing: break
                if 'IP' in packet:
                    for ip_addr in {packet.ip.src, packet.ip.dst}:
                        with detected_ips_lock:
                            if ip_addr not in detected_ips:
                                filepath = os.path.join(OUTPUT_DIR, f"{ip_addr}.pcap")
                                detected_ips[ip_addr] = filepath
                                live_caps[ip_addr] = pyshark.LiveRingCapture(output_file=filepath)
                                print(f"Nuevo dispositivo: {ip_addr}")
                        if ip_addr in live_caps: live_caps[ip_addr].sniff(packet_count=1, packet=packet)
            for cap in live_caps.values(): cap.close()
    except Exception as e: print(f"Error en el hilo de captura: {e}")
    finally:
        is_capturing = False
        capturing_target_ip = None
        print("Hilo de captura finalizado.")

@app.route('/')
def index(): return render_template('index.html')

@app.route('/api/interfaces')
def get_interfaces():
    try:
        result = subprocess.run(['tshark', '-D'], capture_output=True, text=True, check=True, encoding='utf-8')
        # Limpieza de nombres de interfaz para Windows y Linux/macOS
        lines = result.stdout.strip().split('\n')
        interfaces = []
        for line in lines:
            if ' (' in line and ')' in line: # Formato Windows: 1. \Device\NPF_{...} (Wi-Fi)
                interfaces.append(line.split('(')[-1].replace(')','').strip())
            else: # Formato Linux/macOS: 1. eth0
                interfaces.append(line.split('. ')[-1].strip())
        return jsonify(list(filter(None, interfaces))) # Filtra líneas vacías
    except Exception as e:
        print(f"Error al listar interfaces: {e}")
        return jsonify({"error": "No se pudo obtener la lista de interfaces. ¿Está Wireshark instalado y en el PATH?"}), 500

@app.route('/api/start', methods=['POST'])
def start_capture():
    global capture_thread, is_capturing, detected_ips, capturing_target_ip
    if is_capturing: return jsonify({"status": "error", "message": "La captura ya está en progreso."}), 400
    data = request.json
    interface = data.get('interface')
    target_ip = data.get('target_ip')
    if not interface: return jsonify({"status": "error", "message": "No se especificó una interfaz."}), 400
    is_capturing = True
    capturing_target_ip = target_ip
    with detected_ips_lock: detected_ips = {}
    capture_thread = threading.Thread(target=run_capture, args=(interface, target_ip))
    capture_thread.start()
    message = f"Captura iniciada en '{interface}'."
    if target_ip: message += f" Filtrando por IP: {target_ip}"
    return jsonify({"status": "ok", "message": message})

@app.route('/api/stop', methods=['POST'])
def stop_capture():
    global is_capturing
    if not is_capturing: return jsonify({"status": "error", "message": "No hay ninguna captura activa."}), 400
    is_capturing = False
    if capture_thread: capture_thread.join(timeout=5)
    return jsonify({"status": "ok", "message": "La captura ha sido detenida."})

@app.route('/api/status')
def get_status():
    with detected_ips_lock:
        return jsonify({
            "is_capturing": is_capturing,
            "detected_ips": detected_ips,
            "capturing_target_ip": capturing_target_ip
        })

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)

if __name__ == '__main__':
    print("Iniciando servidor web...")
    print(f"Abre tu navegador y ve a http://127.0.0.1:5000")
    app.run(host='0.0.0.0', port=5000, debug=False) # Se recomienda debug=False para evitar que el servidor se reinicie solo.